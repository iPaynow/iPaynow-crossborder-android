package com.example.crossalipaydemo;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.ipaynow.alipay.plugin.api.CrossAliPayPlugin;
import com.ipaynow.alipay.plugin.manager.route.dto.ResponseParams;
import com.ipaynow.alipay.plugin.manager.route.impl.ReceivePayResult;
import com.ipaynow.alipay.plugin.utils.PreSignMessageUtil;
import com.ipaynow.alipay.plugin.view.IpaynowLoading;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements ReceivePayResult {
  
  private EditText mAppIdET;
  private EditText mAppKeyET;
  private EditText mAmtET;
  private EditText mReservedET;
  private EditText mOrderDatailET;
  private EditText mUrlET;
  private EditText mOrderNameET;
  private EditText currencyTypeEdit;
  private EditText CurrFlagEdit;
  private PreSignMessageUtil preSign;
  private IpaynowLoading loading;
  
  
  private static String mAppId = "1480321334800229";//1461826666666666    1480321334800229
  private static String mKey = "BB7qcwBIZeeLQt54BqBthCR5ae4GgXGt";//Plbgh7YEmCAXtA2dLqSW3b4A6eWglVbi   BB7qcwBIZeeLQt54BqBthCR5ae4GgXGt

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    
    preSign = new PreSignMessageUtil();
    
    initUI();

  }

  private void initUI() {
    // 插件内部loading
    loading = CrossAliPayPlugin.getInstance().getDefaultLoading(this);
    mAmtET = (EditText) findViewById(R.id.et_amt);
    mAppIdET = (EditText) findViewById(R.id.et_appid);
    mAppIdET.setText(mAppId);
    mAppKeyET = (EditText) findViewById(R.id.et_appKey);
    mAppKeyET.setText(mKey);
    mReservedET = (EditText) findViewById(R.id.et_resever);
    mUrlET = (EditText) findViewById(R.id.et_url);
    mOrderNameET = (EditText) findViewById(R.id.et_name);
    mOrderDatailET = (EditText) findViewById(R.id.et_detal);
    currencyTypeEdit = (EditText) findViewById(R.id.currencyTypeEdit);
    CurrFlagEdit = (EditText) findViewById(R.id.CurrFlagEdit);
  }

  public void goToPay(View v) {
    preSign.mhtCurrencyType = "NZD";
    preSign.mhtAmtCurrFlag = "0";
    
    if (TextUtils.isEmpty(mAmtET.getText().toString())) {
      Toast.makeText(this, "请输入金额", Toast.LENGTH_SHORT).show();
      return;
    }
    if (TextUtils.isEmpty(mAppIdET.getText().toString())) {
      Toast.makeText(this, "请输入appId", Toast.LENGTH_SHORT).show();
      return;
    }
    if (TextUtils.isEmpty(mAppKeyET.getText().toString())) {
      Toast.makeText(this, "请输入appKey", Toast.LENGTH_SHORT).show();
      return;
    }
    if (TextUtils.isEmpty(mOrderDatailET.getText().toString())) {
      Toast.makeText(this, "请输入订单详情", Toast.LENGTH_SHORT).show();
      return;
    }
    if (!TextUtils.isEmpty(CurrFlagEdit.getText().toString())) {
      preSign.mhtAmtCurrFlag = CurrFlagEdit.getText().toString();
    }
    if (!TextUtils.isEmpty(currencyTypeEdit.getText().toString())) {
      preSign.mhtCurrencyType = currencyTypeEdit.getText().toString();
    }

    String no = new SimpleDateFormat("yyyyMMddHHmmss", Locale.CHINA).format(new Date());
    // 创建订单列表
    prePayMessage(no, no);
    loading.setLoadingMsg("创建订单...");
    loading.show();

    // 生成待签名串
    String preSignStr = preSign.generatePreSignMessage();
    GetMessage gM = new GetMessage();
    gM.execute(preSignStr);
  }

  private void prePayMessage(String mhtOrderNo, String mhtOrderStartTime) {
    preSign.appId = mAppIdET.getText().toString();
    preSign.mhtOrderNo = mhtOrderNo;
    preSign.mhtOrderName = mOrderNameET.getText().toString();
    preSign.mhtOrderAmt = mAmtET.getText().toString();
    preSign.mhtOrderDetail = mOrderDatailET.getText().toString();
    preSign.mhtOrderStartTime = mhtOrderStartTime;
    preSign.mhtReserved = mReservedET.getText().toString();
    preSign.notifyUrl = mUrlET.getText().toString();
    preSign.mhtOrderType = "01";
    preSign.mhtOrderTimeOut = "3600";
    preSign.mhtCharset = "UTF-8";
    preSign.payChannelType = "90";
  }

  public class GetMessage extends AsyncTask<String, Integer, String> {
    protected String doInBackground(String... params) {
      String msg = params[0];
      // String needcheckmsg = HttpUtil.post(GETORDERMESSAGE_URL, msg);
      // 注意：这里只是在前端模拟生成签名，正式发布时请在后台生成签名。
      String needcheckmsg = "mhtSignature=" + Md5Util.md5(msg + "&" + Md5Util.md5(mKey)) + "&mhtSignType=MD5";
      needcheckmsg = msg + "&" + needcheckmsg;
      return needcheckmsg;
    }

    @SuppressWarnings("deprecation")
    protected void onPostExecute(String result) {
      super.onPostExecute(result);
      Log.i("收到的请求信息", result);
      CrossAliPayPlugin.getInstance()
          .setCallResultReceiver(MainActivity.this)// 传入继承了通知接口的类
          .pay(result, MainActivity.this);// 传入请求数据
    }
  }

  @Override
  public void onIpaynowTransResult(ResponseParams resp) {
    if (resp == null) {
      return;
    }
    String respCode = resp.respCode;
    String errorCode = resp.errorCode;
    String respMsg = resp.respMsg;
    StringBuilder temp = new StringBuilder();
    if (respCode.equals("00")) {
      temp.append("交易状态:成功");
    } else if (respCode.equals("02")) {
      temp.append("交易状态:取消");
    } else if (respCode.equals("01")) {
      temp.append("交易状态:失败").append("\n").append("错误码:").append(errorCode).append("原因:" + respMsg);
    } else if (respCode.equals("03")) {
      temp.append("交易状态:未知").append("\n").append("原因:" + respMsg);
    } else {
      temp.append("respCode=").append(respCode).append("\n").append("respMsg=").append(respMsg);
    }
    Toast.makeText(this, temp.toString(), Toast.LENGTH_LONG).show();
  }

  @Override
  protected void onDestroy() {
    CrossAliPayPlugin.getInstance().onActivityDestroy();
    super.onDestroy();
  }
}
